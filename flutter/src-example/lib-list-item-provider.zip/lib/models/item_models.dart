class Item {
  final String name;
  final int quantity;

  Item(this.name, this.quantity);
}