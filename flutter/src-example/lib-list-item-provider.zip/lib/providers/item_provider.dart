import 'package:flutter/widgets.dart';
import '../models/item_models.dart';

class ItemProvider with ChangeNotifier {
  List<Item> _items = [
    Item("Item 1", 1),
    Item("Item 2", 2),
    Item("Item 3", 3),
    Item("Item 4", 4),
    Item("Item 5", 5),
    Item("Item 6", 6),
    Item("Item 7", 7),
    Item("Item 8", 8),
    Item("Item 9", 9),
    Item("Item 10", 10),
  ];

  List<Item> get items => _items;

  void addItem(Item data) {
    _items.add(data);
    notifyListeners();
  }
}
