import 'package:flutter/material.dart';

class CookieProvider extends ChangeNotifier {
  int _cookieCount = 0;
  int get cookieCount => _cookieCount;

  void buyCookie() {
    ++_cookieCount;
    notifyListeners();
  }

  void resetCount() {
    _cookieCount = 0;
    notifyListeners();
  }

  void addTwoCount(){
    _cookieCount += 2;
    notifyListeners();
  }
}
