import 'package:flutter/material.dart';
import 'package:flutter_provider_latihan_chatgpt/providers/cookie_provider.dart';
import 'package:provider/provider.dart';

import '../widgets/drawer_widget.dart';

class CookiePage extends StatelessWidget {
  const CookiePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Cookie Shop"),
      ),
      drawer: const DrawerWidget(),
      body: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Consumer<CookieProvider>(
                builder: (context, value, child) {
                  return Text(
                    'Cookie Count: ${value.cookieCount}',
                    style: const TextStyle(fontSize: 20),
                  );
                },
              ),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: () {
                  Provider.of<CookieProvider>(context, listen: false)
                      .buyCookie();
                },
                child: const Text("Click to Buy"),
              ),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: () {
                  Provider.of<CookieProvider>(context, listen: false)
                      .resetCount();
                },
                child: const Text("Reset data"),
              ),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: () {
                  Provider.of<CookieProvider>(context, listen: false)
                      .addTwoCount();
                },
                child: Consumer<CookieProvider>(
                    builder: (context, valueAddTwoCount, child) {
                  return Text(
                      "Add 2 count data ${valueAddTwoCount.cookieCount}");
                }),
              )
            ],
          )
        ],
      ),
    );
  }
}
