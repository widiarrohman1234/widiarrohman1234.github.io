import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/item_provider.dart';
import '../../widgets/drawer_widget.dart';
import 'create_item_page.dart';

class ItemListPage extends StatelessWidget {
  const ItemListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("List Item"),
          actions: const [],
        ),
        drawer: const DrawerWidget(),
        body: Consumer<ItemProvider>(
          builder: (context, value, child) {
            return ListView.builder(
              itemCount: value.items.length,
              itemBuilder: (context, index) {
                final item = value.items[index];
                return ListTile(
                  title: Text(item.name),
                  subtitle: Text("Quantity ${item.quantity}"),
                );
              },
            );
          },
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>  CreateItemPage(),
                )
            );
          },
          tooltip: 'Add Item',
          child: Icon(Icons.add),
        ));
  }
}
