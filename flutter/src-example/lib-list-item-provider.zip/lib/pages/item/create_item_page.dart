// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/item_models.dart';
import '../../providers/item_provider.dart';

class CreateItemPage extends StatelessWidget {
  CreateItemPage({super.key});
  final TextEditingController _nameItem = TextEditingController();
  final TextEditingController _quantity = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Create Item"),
        actions: const [],
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              TextFormField(
                  controller: _nameItem,
                  decoration: const InputDecoration(label: Text("Name Item"))),
              const SizedBox(height: 16.0),
              TextFormField(
                  controller: _quantity,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    label: Text("Quantity"),
                  )),
              const SizedBox(height: 16.0),
              ElevatedButton(
                  onPressed: () {
                    final name = _nameItem.text;
                    final quantity = int.tryParse(_quantity.text) ?? 0;

                    final itemProviders =
                        Provider.of<ItemProvider>(context, listen: false);
                    final newItem = Item(name, quantity);
                    itemProviders.addItem(newItem);
                    Navigator.pop(context);
                  },
                  child: const Text("Submit"))
            ],
          ),
        ),
      ),
    );
  }
}
