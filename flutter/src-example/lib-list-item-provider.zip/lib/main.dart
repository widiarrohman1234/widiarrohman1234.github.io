import 'package:flutter/material.dart';
import 'package:flutter_provider_latihan_chatgpt/pages/home_page.dart';
import 'package:flutter_provider_latihan_chatgpt/providers/cookie_provider.dart';
import 'package:provider/provider.dart';

import 'providers/item_provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => CookieProvider()),
        ChangeNotifierProvider(create: (context) => ItemProvider()),
      ],
      child: const MaterialApp(
        title: 'Provider App',
        home: HomePage(),
      ),
    );
  }
}
